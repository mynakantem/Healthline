
default_app_config = 'dynamic_models.DynamicModelsConfig'
