### start-project
``` sh
Usage: zango start-project [OPTIONS] PROJECT_NAME

  Create Project

Options:
  --directory TEXT    Project Directory
  --db_name TEXT      DB Name
  --db_user TEXT      DB User
  --db_password TEXT  DB Password
  --db_host TEXT      DB Host
  --db_port TEXT      DB Port
  --help              Show this message and exit.

```